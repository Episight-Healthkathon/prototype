"""Run the existing benchmark with explicit live settings and safe progress metadata."""
import json
import time
from datetime import UTC, datetime
from pathlib import Path

from episight.batch import ALL_MODES, default_planner_factory, run_batch
from episight.llm.config import LlmSettings, Provider

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
settings = LlmSettings(
    provider=Provider.OPENAI,
    model="gpt-4o-mini",
    replay="off",
)
if not settings.openai_api_key:
    raise SystemExit("No OpenAI key available; benchmark not started.")

# Stop on persistent API failures rather than complete a misleading fallback-only run.
from episight.llm.clients import LlmError, OpenAIClient

original_complete = OpenAIClient.complete_json
consecutive_errors = 0
api_calls = 0
api_errors = 0


def guarded_complete(self, system, user, schema):
    global consecutive_errors, api_calls, api_errors
    api_calls += 1
    try:
        reply = original_complete(self, system, user, schema)
    except LlmError as exc:
        consecutive_errors += 1
        api_errors += 1
        if consecutive_errors >= 3:
            raise RuntimeError("Three consecutive API failures; stopped live benchmark.") from None
        raise exc
    consecutive_errors = 0
    return reply


OpenAIClient.complete_json = guarded_complete
factory, info = default_planner_factory(OUT / "recordings", settings)
started = datetime.now(UTC).isoformat()
clock_start = time.perf_counter()


def progress(message):
    elapsed = round(time.perf_counter() - clock_start, 1)
    entry = {"at": datetime.now(UTC).isoformat(), "elapsed_s": elapsed, "case": message}
    with (OUT / "progress.jsonl").open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(entry) + "\n")
    print(f"[{elapsed:.1f}s] {message}", flush=True)


try:
    written = run_batch(
        ROOT / "data/synthetic/v0.1.0",
        ROOT / "data/policies/pc-0.1.1",
        OUT,
        ALL_MODES,
        repeats=3,
        recordings=OUT / "recordings",
        planner_factory=factory,
        planner_info=info,
        progress=progress,
    )
finally:
    (OUT / "live_metadata.json").write_text(
        json.dumps({
            "started_at": started,
            "finished_at": datetime.now(UTC).isoformat(),
            "wall_seconds": round(time.perf_counter() - clock_start, 3),
            "provider": info.provider,
            "model": info.model,
            "prompt_version": info.prompt_version,
            "api_calls": api_calls,
            "api_errors": api_errors,
            "replay": "off",
        }, indent=2) + "\n", encoding="utf-8",
    )
for path in written.values():
    print(f"wrote {path}", flush=True)
