"""Verify live benchmark completeness against labels and replay every FULL case."""
import json
from collections import defaultdict
from pathlib import Path

from episight.batch import default_planner_factory, run_batch
from episight.contracts.enums import InvestigationMode
from episight.llm.config import LlmSettings, Provider

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
live = json.loads((OUT / "FULL.json").read_text(encoding="utf-8"))
labels = [json.loads(line) for line in (ROOT / "data/ground-truth/v0.1.0/cases.jsonl").read_text(
    encoding="utf-8").splitlines() if line.strip()]
positive = {tuple(sorted(g["anchor_episode_ids"])): g for g in labels if g["expected_signal_type"]}
# Ground-truth negatives have expected_outcome null and must never appear in screening.
expected_slots = {(key, i) for key in positive for i in range(3)}
observed_slots = {(tuple(sorted(c["anchor_episode_ids"])), c["run_index"]) for c in live["cases"]}
assert len(live["cases"]) == len(observed_slots) == len(expected_slots) == 60
assert expected_slots == observed_slots
assert {tuple(sorted(x)) for x in live["screening"]["flagged_anchor_sets"]} == set(positive)
errors = []
states = defaultdict(set)
for case in live["cases"]:
    key = tuple(sorted(case["anchor_episode_ids"]))
    gt = positive[key]
    if (case["outcome"], case["stop_reason"]) != (gt["expected_outcome"], gt["expected_stop_reason"]):
        errors.append({"gt_id": gt["gt_id"], "run_index": case["run_index"], "kind": "outcome_or_stop"})
    for name, value in gt.get("expected_requirement_states", {}).items():
        if case["requirement_states"].get(name) != value:
            errors.append({"gt_id": gt["gt_id"], "run_index": case["run_index"], "kind": name})
    states[gt["gt_id"]].add((case["outcome"], case["stop_reason"]))

settings = LlmSettings(provider=Provider.OPENAI, model="gpt-4o-mini", replay="replay", openai_api_key="replay")
factory, info = default_planner_factory(OUT / "recordings", settings)
run_batch(
    ROOT / "data/synthetic/v0.1.0", ROOT / "data/policies/pc-0.1.1", OUT / "replay",
    [InvestigationMode.FULL], repeats=3, recordings=OUT / "recordings",
    planner_factory=factory, planner_info=info, progress=lambda msg: print(msg, flush=True),
)
replayed = json.loads((OUT / "replay/FULL.json").read_text(encoding="utf-8"))
differences = []
for original, repeated in zip(live["cases"], replayed["cases"], strict=True):
    original = {k: v for k, v in original.items() if k != "elapsed_ms"}
    repeated = {k: v for k, v in repeated.items() if k != "elapsed_ms"}
    for item in (original, repeated):
        item["brief"] = {k: v for k, v in item["brief"].items() if k != "generated_at"}
    if original != repeated:
        differences.append({"case_id": original["case_id"], "run_index": original["run_index"],
                            "fields": sorted(k for k in original if original[k] != repeated.get(k))})
result = {
    "expected_runs": len(expected_slots), "observed_runs": len(observed_slots),
    "screening_anchor_sets_match": True, "independent_label_errors": errors,
    "unstable_outcomes": sorted(key for key, values in states.items() if len(values) > 1),
    "replay_semantic_differences": differences,
    "replay_comparison": "All case fields except elapsed_ms and brief.generated_at; includes brief content, states and planner provenance",
}
(OUT / "verification.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
if errors or differences:
    raise SystemExit(1)
